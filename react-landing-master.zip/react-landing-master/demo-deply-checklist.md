App.js - <Router basename="/react-landing">



It's only for demo purpose.
!!!!! Dont follow instrucitons in this file !!!!!